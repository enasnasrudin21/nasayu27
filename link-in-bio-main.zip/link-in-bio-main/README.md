Link-in-bio
=========================

## License

MIT by Takuya Matsuyama

You can create your own link-in-bio page for free without notifying me by forking this project under the following conditions:

- Add a link to [my homepage](https://www.craftz.dog/) anywhere
- Do not use the Japanese garden picture
